import numpy as np
import matplotlib.pyplot as plt
from queue import PriorityQueue


def lambda1(t):
    return max(0.0, -(1/3650)*t**2 + (1/10)*t)

def lambda2(t):
    return lambda1(t) / 5.0

def next_arrival(t, rate_fn, rate_max):
    while True:
        t += np.random.exponential(1.0 / rate_max)
        if t >= 365:
            return np.inf
        if np.random.rand() < rate_fn(t) / rate_max:
            return t

def sample_los(mu, los_dist):
    if los_dist == 'lognormal':
        return np.random.lognormal(mu, np.sqrt(np.log(2)))
    else:
        return np.random.exponential(np.exp(mu + np.log(2)/2))


def simulate(beds_a, beds_b, beds_c, los_dist='lognormal', seed=None, track=False):
    if seed is not None:
        np.random.seed(seed)

    occ_a = occ_b = occ_c = 0
    arrivals    = {'A': 0, 'B': 0, 'C': 0}
    relocations = {'A': 0, 'B': 0, 'C': 0}
    full_on_arr = {'A': 0, 'B': 0, 'C': 0}
    last_t      = 0.0
    occ_time    = {'A': 0.0, 'B': 0.0, 'C': 0.0}
    history     = [(0.0, 0, 0, 0)] if track else None

    events = PriorityQueue()
    events.put((next_arrival(0, lambda1, 9.2),  'ArrivalA'))
    events.put((next_arrival(0, lambda2, 1.84), 'ArrivalB'))
    events.put((np.random.exponential(1/6),     'ArrivalC'))

    while not events.empty():
        t, event = events.get()
        dt = min(t, 365) - last_t
        occ_time['A'] += occ_a * dt
        occ_time['B'] += occ_b * dt
        occ_time['C'] += occ_c * dt
        last_t = min(t, 365)

        if t >= 365:
            break

        if event == 'ArrivalA':
            arrivals['A'] += 1
            if occ_a < beds_a:
                occ_a += 1
                events.put((t + sample_los(np.log(4*np.sqrt(2)), los_dist), 'DepartA'))
            else:
                full_on_arr['A'] += 1
                relocations['A'] += 1
            events.put((next_arrival(t, lambda1, 9.2), 'ArrivalA'))

        elif event == 'ArrivalB':
            arrivals['B'] += 1
            if occ_b < beds_b:
                occ_b += 1
                events.put((t + sample_los(np.log(6*np.sqrt(2)), los_dist), 'DepartB'))
            else:
                full_on_arr['B'] += 1
                if occ_a < beds_a:
                    occ_a += 1
                    events.put((t + sample_los(np.log(6*np.sqrt(2)), los_dist), 'DepartA'))
                else:
                    relocations['B'] += 1
            events.put((next_arrival(t, lambda2, 1.84), 'ArrivalB'))

        elif event == 'ArrivalC':
            arrivals['C'] += 1
            if occ_c < beds_c:
                occ_c += 1
                events.put((t + sample_los(np.log(5*np.sqrt(2)), los_dist), 'DepartC'))
            else:
                full_on_arr['C'] += 1
                relocations['C'] += 1
            events.put((t + np.random.exponential(1/6), 'ArrivalC'))

        elif event == 'DepartA':
            occ_a -= 1
        elif event == 'DepartB':
            occ_b -= 1
        elif event == 'DepartC':
            occ_c -= 1

        if track:
            history.append((t, occ_a, occ_b, occ_c))

    return {
        'arrivals':    arrivals,
        'relocations': relocations,
        'prob_full':   {w: full_on_arr[w] / arrivals[w] if arrivals[w] else 0.0 for w in 'ABC'},
        'utilisation': {w: occ_time[w] / (365 * beds) for w, beds in zip('ABC', [beds_a, beds_b, beds_c])},
        'total_reloc': sum(relocations.values()),
        'history':     history
    }


def run_replications(n, beds_a, beds_b, beds_c, los_dist='lognormal'):
    results = [simulate(beds_a, beds_b, beds_c, los_dist, seed=i) for i in range(n)]

    print(f"\n{n} reps | beds A={beds_a} B={beds_b} C={beds_c} | dist={los_dist}")
    for ward in 'ABC':
        prob_full  = np.mean([r['prob_full'][ward]    for r in results])
        mean_reloc = np.mean([r['relocations'][ward] for r in results])
        mean_util  = np.mean([r['utilisation'][ward] for r in results])

        plt.hist([r['prob_full'][ward] for r in results],label=f"Ward {ward}",bins=20)

        print(f"  Ward {ward}: P(full)={prob_full:.3f}  reloc={mean_reloc:.1f}  util={mean_util:.3f}")
    plt.legend()
    plt.show()
    total_reloc = np.mean([r['total_reloc'] for r in results])
    print(f"  Total relocations: {total_reloc:.1f}")


def plot_occupancy(beds_a, beds_b, beds_c, los_dist='lognormal', n_runs=30):
    daily = np.arange(366)
    fracs = {'A': [], 'B': [], 'C': []}

    for seed in range(n_runs):
        history = simulate(beds_a, beds_b, beds_c, los_dist, seed=seed, track=True)['history']
        ts  = np.array([h[0] for h in history])
        occ = np.array([[h[1], h[2], h[3]] for h in history])
        idx = np.clip(np.searchsorted(ts, daily, side='right') - 1, 0, len(ts) - 1)
        fracs['A'].append(occ[idx, 0] / beds_a)
        fracs['B'].append(occ[idx, 1] / beds_b)
        fracs['C'].append(occ[idx, 2] / beds_c)

    fig, axes = plt.subplots(3, 1, figsize=(10, 8), sharex=True)
    for ax, ward, beds in zip(axes, 'ABC', [beds_a, beds_b, beds_c]):
        mean = np.mean(fracs[ward], axis=0)
        std  = np.std(fracs[ward], axis=0)
        ax.plot(daily, mean, label=f'Ward {ward} ({beds} beds)')
        ax.fill_between(daily, mean - std, mean + std, alpha=0.25)
        ax.axhline(1.0, linestyle='--', color='black', alpha=0.3)
        ax.set_ylabel('Fraction occupied')
        ax.set_ylim(0, 1.15)
        ax.legend(loc='upper left')

    axes[-1].set_xlabel('Day')
    plt.tight_layout()
    plt.savefig('occupancy.png', dpi=120)
    plt.show()


def grid_search(total_beds=75, step=5, n_reps=50, plot=True):
    data = []
    for beds_a in range(step, total_beds, step):
        for beds_b in range(step, total_beds - beds_a, step):
            beds_c = total_beds - beds_a - beds_b
            reps = [simulate(beds_a, beds_b, beds_c, seed=i) for i in range(n_reps)]
            mean_reloc = np.mean([r['total_reloc'] for r in reps])
            data.append((beds_a, beds_b, beds_c, mean_reloc))

    best = min(data, key=lambda x: x[3])
    print(f"\nGrid search: {len(data)} configurations, {n_reps} reps each")
    print(f"  Best: beds A={best[0]} B={best[1]} C={best[2]}  mean_reloc={best[3]:.1f}")

    if plot:
        a_vals = sorted(set(d[0] for d in data))
        b_vals = sorted(set(d[1] for d in data))
        grid = np.full((len(b_vals), len(a_vals)), np.nan)
        reloc_lookup = {(d[0], d[1]): d[3] for d in data}
        for i, b in enumerate(b_vals):
            for j, a in enumerate(a_vals):
                if (a, b) in reloc_lookup:
                    grid[i, j] = reloc_lookup[(a, b)]

        plt.figure()
        plt.pcolormesh(a_vals, b_vals, grid, cmap='viridis_r', shading='nearest')
        plt.colorbar(label='Mean total relocations')
        plt.scatter([best[0]], [best[1]], color='red', marker='*', s=200, zorder=5,
                    label=f'Best: A={best[0]} B={best[1]} C={best[2]}')
        plt.xlabel('Beds in Ward A')
        plt.ylabel('Beds in Ward B')
        plt.legend()
        plt.tight_layout()
        plt.savefig('grid_search.png', dpi=120)
        plt.show()

    return best[0], best[1], best[2]


def beds_sensitivity(totals=[60, 70, 80, 100], step=5, n_reps=100):
    summary = []
    for total in totals:
        beds_a, beds_b, beds_c = grid_search(total, step=step, n_reps=20, plot=False)
        results = [simulate(beds_a, beds_b, beds_c, seed=i) for i in range(n_reps)]

        mean_arrivals  = {w: np.mean([r['arrivals'][w]    for r in results]) for w in 'ABC'}
        mean_reloc     = {w: np.mean([r['relocations'][w] for r in results]) for w in 'ABC'}
        mean_prob_full = {w: np.mean([r['prob_full'][w]   for r in results]) for w in 'ABC'}
        total_reloc    = np.mean([r['total_reloc'] for r in results])

        summary.append({
            'total': total, 'config': (beds_a, beds_b, beds_c),
            'arrivals': mean_arrivals, 'reloc': mean_reloc,
            'prob_full': mean_prob_full, 'total_reloc': total_reloc
        })
        print(f"  {total} beds -> optimal A={beds_a} B={beds_b} C={beds_c}: mean_reloc={total_reloc:.1f}")

    xs = [s['total'] for s in summary]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))

    ax1.plot(xs, [s['total_reloc'] for s in summary], 'o-')
    for s in summary:
        a, b, c = s['config']
        ax1.annotate(f'A={a},B={b},C={c}', (s['total'], s['total_reloc']),
                     textcoords='offset points', xytext=(6, 4), fontsize=8)
    ax1.set_xlabel('Total beds')
    ax1.set_ylabel('Mean total relocations')
    ax1.set_xticks(xs)

    for ward in 'ABC':
        ax2.plot(xs, [s['prob_full'][ward] for s in summary], 'o-', label=f'Ward {ward}')
    ax2.set_xlabel('Total beds')
    ax2.set_ylabel('P(full on arrival)')
    ax2.set_xticks(xs)
    ax2.legend()

    plt.tight_layout()
    plt.savefig('beds_sensitivity.png', dpi=120)
    plt.show()

    header = (f"{'Total':>5} | {'Config':>16} | "
              f"{'Admit A':>8} {'Admit B':>8} {'Admit C':>8} | "
              f"{'Block A':>8} {'Block B':>8} {'Block C':>8} | {'Total blocks':>12}")
    print(f"\n{header}")
    print('-' * len(header))
    for s in summary:
        a, b, c = s['config']
        admit = {w: s['arrivals'][w] - s['reloc'][w] for w in 'ABC'}
        print(f"  {s['total']:>3} | A={a:>2} B={b:>2} C={c:>2}      | "
              f"{admit['A']:>8.1f} {admit['B']:>8.1f} {admit['C']:>8.1f} | "
              f"{s['reloc']['A']:>8.1f} {s['reloc']['B']:>8.1f} {s['reloc']['C']:>8.1f} | "
              f"{s['total_reloc']:>12.1f}")


def plot_arrival_rates():
    ts = np.linspace(0, 365, 366)
    plt.plot(ts, [lambda1(t) for t in ts], label='Ward A  l1(t)')
    plt.plot(ts, [lambda2(t) for t in ts], label='Ward B  l2 = l1/5')
    plt.axhline(6, linestyle='--', label='Ward C  l3 = 6')
    plt.xlabel('Day')
    plt.ylabel('Patients / day')
    plt.legend()
    plt.tight_layout()
    plt.savefig('arrival_rates.png', dpi=120)
    plt.show()


#plot_arrival_rates()
#run_replications(200, beds_a=15, beds_b=10, beds_c=50)
#plot_occupancy(beds_a=25, beds_b=5, beds_c=45)
#run_replications(200, beds_a=20, beds_b=10, beds_c=45, los_dist='exponential')
#grid_search(total_beds=75, step=5, n_reps=50)
beds_sensitivity(totals=[60,65, 70,75, 80,85,90,95, 100], step=5, n_reps=20)
